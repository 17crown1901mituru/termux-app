include(":app", ":termux-core", ":termux-shared", ":terminal-emulator", ":terminal-view", ":lunar-ui", ":taskexecutor-shared")
