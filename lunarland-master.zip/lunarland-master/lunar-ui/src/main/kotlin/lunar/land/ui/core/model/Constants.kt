﻿package lunar.land.ui.core.model

object Constants {
    object Defaults {
        const val DEFAULT_CLOCK_24_ANALOG_RADIUS = 30f
    }
}

