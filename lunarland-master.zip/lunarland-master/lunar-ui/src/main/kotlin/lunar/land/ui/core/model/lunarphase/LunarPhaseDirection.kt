﻿package lunar.land.ui.core.model.lunarphase

enum class LunarPhaseDirection {
    NEW_TO_FULL,
    FULL_TO_NEW
}

