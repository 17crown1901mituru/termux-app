package com.termux.app.taskexecutor.model

/**
 * Task Executor Input Mode
 */
enum class TaskExecutorMode {
    TEXT,
    VOICE
}

